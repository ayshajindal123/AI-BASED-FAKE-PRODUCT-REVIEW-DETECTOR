def scrape_reviews(url):
    return [
        "Product is good",
        "Worth the price",
        "Bad quality",
        "Very fake review"
    ]
